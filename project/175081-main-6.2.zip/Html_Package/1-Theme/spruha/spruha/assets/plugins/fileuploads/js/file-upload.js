$('.dropify').dropify({
	messages: {
		'default': 'یک فایل را در اینجا بکشید و رها کنید یا کلیک کنید',
		'replace': 'کشیدن و رها کردن یا کلیک کنید تا جایگزین شود',
		'remove': 'برداشتن',
		'error': 'اوه ، مشکلی اضافه شد'
	},
	error: {
		'fileSize': 'The file size is too big (2M max).'
	}
});
	
